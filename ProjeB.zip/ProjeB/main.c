/**
* @file main.c
* @description Yazdığım fonksiyonların kontrolünü burada yapıyorum
* @assignment 1.ödev
* @date 23.12.2024
* @author Melike Yıldız - melike.yildiz@stu.fsm.edu.tr
*/



#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "proje1.h"



int main(int argc, char *argv[])
{

    FILE *birimText = (FILE *)malloc(sizeof(FILE));
    FILE *calisanText = (FILE *)malloc(sizeof(FILE));
    char *birimDosya = argv[1];
    char *calisanDosya = argv[2];

    birim **birimler = (birim **)malloc(sizeof(birim *));

    calisan *test_calisan_1 = returnCalisan("Fatih", "Yildiz", 1234, 20000, 2010);
    calisan *test_calisan_2 = returnCalisan("Kaan", "Yildiz", 789, 21000, 2024);
    calisan *test_calisan_3 = returnCalisan("melike", "yildiz", 1234, 50000, 2019);
    calisan *test_calisan_4 = returnCalisan("fatma","aras",456,75000,2018);
    calisan *test_calisan_5 =returnCalisan("didar","kayalilar",789,45000,2015);

    calisanYazdir(test_calisan_1);
    calisanYazdir(test_calisan_2);
    calisanYazdir(test_calisan_3);
    calisanYazdir(test_calisan_4);
    calisanYazdir(test_calisan_5);
    printf("----------------------------------------\n");

    birim *muhasebe = returnBirim("Muhasebe", 1234);
    birim *satisDanismani = returnBirim("SatisDanismani", 789);
    birim *kasiyer=returnBirim("kasiyer",456);

    birimYazdir(muhasebe);
    birimYazdir(satisDanismani);
    birimYazdir(kasiyer);
    printf("-------------------------------------------\n");

    muhasebe->birimCalisanlar = birimDiziyeEkle(muhasebe, test_calisan_1);
    satisDanismani->birimCalisanlar = birimDiziyeEkle(satisDanismani, test_calisan_2);
    muhasebe->birimCalisanlar = birimDiziyeEkle(muhasebe, test_calisan_3);
    kasiyer->birimCalisanlar=birimDiziyeEkle(kasiyer,test_calisan_4);
    satisDanismani->birimCalisanlar=birimDiziyeEkle(satisDanismani,test_calisan_5);
    printf("---------------------------------------\n");
    birimler = birimlerAta(muhasebe, birimler);  
    birimler = birimlerAta(satisDanismani, birimler);
    birimler = birimlerAta(kasiyer,birimler);

    printf("Birimlerin ilk birim adi: %s\n", birimler[0]->birimAdi);
    printf("Birimlerin ikinci birim adi: %s\n", birimler[1]->birimAdi);
    printf("Birimin calisani %s\n", birimler[0]->birimCalisanlar[0]->calisanAdi);
    printf("birimin ikinci calisani %s\n", birimler[0]->birimCalisanlar[1]->calisanAdi);
    printf("ikinci birim adi: %s\n", birimler[2]->birimAdi);
    printf("ikinci birimin calisani: %s\n", birimler[2]->birimCalisanlar[0]->calisanAdi);

    printf("----------------------------------------\n");
    
    printf("Muhasebe birimini ortalama maasi: %.2f\n", birimCalisanMaasHesapla(muhasebe));
    printf("Satis danismani biriminin ortalama maasi: %.2f\n", birimCalisanMaasHesapla(satisDanismani));
    printf("Kasiyer biriminin ortalama maasi: %.2f\n", birimCalisanMaasHesapla(kasiyer));
    printf("------------------------------\n");
    ortalamaUstuMaas(muhasebe);
    ortalamaUstuMaas(satisDanismani);
    ortalamaUstuMaas(kasiyer);
    printf("---------------------------\n");
    birimEnYuksekMaas(muhasebe);
    printf("---------------------------\n");
    maasDegistir(30000, muhasebe);
    printf("----------------------------\n");
    dosyayaBirimYaz(birimler, birimText, birimDosya);
    dosyayaCalisanYaz(calisanText, calisanDosya, birimler);
    printf("----------------------------\n");
    
    birimler = birimDosyadanYazdir(birimText, birimDosya);
    printf(birimler[0]->birimAdi);

    printf("----------------------------\n");

    calisanDosyadanYazdir(birimler, calisanText, calisanDosya);
    printf("%s", birimler[1]->birimCalisanlar[0]->calisanAdi);

    printf("----------------------------\n");

    birimDiziYazdir(birimler);


    return 0;
}