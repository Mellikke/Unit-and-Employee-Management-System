/**
* @file proje1.c
* @description Bütün fonksiyonlarım burada ve gerekli işlemleri yapıyor.
* @assignment 1. ödev
* @date 23.12.2024
* @author Melike Yıldız - melike.yildiz@stu.fsm.edu.tr
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "proje1.h"

int birimSayisi = 0;

calisan *returnCalisan(char *calisanAdi, char *calisanSoyadi, unsigned short int birimKodu, float maas, int girisYili)
{
    calisan *c1 = (calisan *)malloc(sizeof(calisan));

    if (c1 != NULL)
    {
        c1->calisanAdi = (char *)malloc(30 * sizeof(char));
        c1->calisanSoyadi = (char *)malloc(30 * sizeof(char));
        strcpy(c1->calisanAdi, calisanAdi);
        strcpy(c1->calisanSoyadi, calisanSoyadi);
        c1->birimKodu = birimKodu;
        c1->maas = maas;
        c1->girisYili = girisYili;
    }
    else
    {
        printf("Bellek hatasi!");
    }

    return c1;
}

birim *returnBirim(char *birimAdi, unsigned short int birimKodu)
{

    birim *b1 = (birim *)malloc(sizeof(birim));

    if (b1 != NULL)
    {
        b1->birimAdi = (char *)malloc(30 * sizeof(char));
        strcpy(b1->birimAdi, birimAdi);
        b1->birimKodu = birimKodu;
        b1->birimCalisanlar = (calisan **)malloc(20 * sizeof(calisan *));
        b1->calisanSayisi = 0;
        for (int i = 0; i < 20; i++)
        {
            b1->birimCalisanlar[i] = NULL;
        }
    }
    else
    {
        printf("Bellek hatasi!");
    }

    return b1;
}

calisan **birimDiziyeEkle(birim *hedefBirim, calisan *hedefCalisan)
{
    // Birim çalışanlar dizisinin boyutunu artırmak için realloc kullanıyoruz
    calisan **calisanlar = (calisan **)realloc(hedefBirim->birimCalisanlar, (hedefBirim->calisanSayisi + 1) * sizeof(calisan *));
     // Çalışanları dizide boş bir yer bulup ekliyoruz
    for (int i = 0; i < 20; i++)
    {
        if (calisanlar[i] == NULL)
        {
            calisanlar[i] = hedefCalisan;
            hedefBirim->calisanSayisi++;
            break;
        }
    }
    return calisanlar;
}

birim **birimlerAta(birim *nesne, birim **birimler)
{
    // Birim dizisinin boyutunu arttırmak için realloc kullanıyoruz
    birim **temp = (birim **)realloc(birimler, (birimSayisi + 1) * sizeof(birim *));
    if (temp == NULL)
    {
        printf("Bellek hatasi");
    }
    birimSayisi++;
    // Yeni birimi dizinin sonuna ekliyoruz
    temp[birimSayisi - 1] = nesne;
    return temp;
}

void calisanYazdir(calisan *c)
{
    printf("Calisanin adi: %s\n", c->calisanAdi);
    printf("Calisanin soyadi: %s\n", c->calisanSoyadi);
    printf("Calisanin birim kodu: %d\n", c->birimKodu);
    printf("Calisanin maasi: %.2f\n", c->maas);
    printf("Calisanin giris yili: %d\n", c->girisYili);
    printf("\n");
}
void birimYazdir(birim *b)
{
    printf("Birim adi: %s\n", b->birimAdi);
    printf("Birim kodu: %d\n", b->birimKodu);
    printf("\n");
}
void birimDiziYazdir(birim **birimler)
{
    for (int i = 0; i < birimSayisi ; i++)
    {
        if (birimler[i]->birimAdi != NULL)
        {
            printf("Birim adi: %s\n", birimler[i]->birimAdi);
            printf("Birim kodu: %d\n", birimler[i]->birimKodu);
            for (int j = 0; j < birimler[i]->calisanSayisi; j++)
            {
                if (birimler[i]->birimCalisanlar[j]->calisanAdi != NULL)
                {
                    printf("Calisanin adi: %s\n ", birimler[i]->birimCalisanlar[j]->calisanAdi);
                    printf("Calisanin soyadi: %s\n", birimler[i]->birimCalisanlar[j]->calisanSoyadi);
                    printf("Calisanin maasi:%.2f\n ", birimler[i]->birimCalisanlar[j]->maas);
                    printf("Calisanin giris yili: %d\n", birimler[i]->birimCalisanlar[j]->girisYili);
                    printf("*\n");
                }
                else
                {
                    printf("İlgili birimin calisani bulunmamaktadir!");
                }
            }
        }
        else
        {
            printf("undefined birim adi");
        }
    }
}
float birimCalisanMaasHesapla(birim *b)
{

    float maasToplam = 0.0;
    if (b->calisanSayisi <= 0)
    {
        return 0.0;
    }
    for (int i = 0; i < b->calisanSayisi; i++)
    {
        maasToplam += b->birimCalisanlar[i]->maas;
    }
    float ortalama = maasToplam / b->calisanSayisi;
    return ortalama;
}
void ortalamaUstuMaas(birim *b)
{

    float ortalama = birimCalisanMaasHesapla(b);

    for (int i = 0; i < b->calisanSayisi; i++)
    {
        if (b->birimCalisanlar[i]->maas > ortalama)
        {
            printf("ortalama uzeri maas alan : %s\n", b->birimCalisanlar[i]->calisanAdi);
        }
    }
}

void birimEnYuksekMaas(birim *b)
{

    int max = b->birimCalisanlar[0]->maas;
    for (int i = 0; i < b->calisanSayisi; i++)
    {
        if (max < b->birimCalisanlar[i]->maas)
        {
            max = b->birimCalisanlar[i]->maas;
            printf("ilgili birimin en yuksek maas alan calisani: %s\n", b->birimCalisanlar[i]->calisanAdi);
        }
    }
}
void maasDegistir(float istenenMaas, birim *b)
{

    for (int i = 0; i < b->calisanSayisi; i++)
    {
        int calismaYili = 2024 - (b->birimCalisanlar[i]->girisYili);
        //istenen şartın kontrolünü yapıyoruz
        if (calismaYili > 10 && b->birimCalisanlar[i]->maas < istenenMaas)
        {
            b->birimCalisanlar[i]->maas = istenenMaas;
            printf("Maasi degismesi gereken kisi: %s %s", b->birimCalisanlar[i]->calisanAdi, b->birimCalisanlar[i]->calisanSoyadi);
            printf(" calisanin maasi : %.2f olarak guncellendi.\n", istenenMaas);
        }
    }
}

void dosyayaBirimYaz(birim **b,FILE *birimText,char *birimDosya){
    birimText=fopen(birimDosya,"w");
    if(birimText){
        printf("Dosya acildi!\n");
        printf("%d",birimSayisi);
        for(int i=0;i<birimSayisi;i++){
            fprintf(birimText,"%s\n",b[i]->birimAdi);
            fprintf(birimText,"%hu\n",b[i]->birimKodu);
            fprintf(birimText,"%d\n",b[i]->calisanSayisi);  
        }
    }
    fclose(birimText);
}

void dosyayaCalisanYaz(FILE *calisanText,char *calisanDosya,birim **birimler){
    //Dosyayı açıyoruz
    calisanText=fopen(calisanDosya,"w");
    if(calisanText){
        printf("Dosya acildi!\n");
        int toplam=0;
        for(int i=0;i<birimSayisi;i++){
            toplam+=birimler[i]->calisanSayisi;
            
        }
        for(int j=0;j<birimSayisi;j++){
            for(int k=0;k<birimler[j]->calisanSayisi;k++){
                fprintf(calisanText,"%s\n",birimler[j]->birimCalisanlar[k]->calisanAdi);
                fprintf(calisanText,"%s\n",birimler[j]->birimCalisanlar[k]->calisanSoyadi);
                fprintf(calisanText,"%hu\n",birimler[j]->birimCalisanlar[k]->birimKodu);
                fprintf(calisanText,"%d\n",birimler[j]->birimCalisanlar[k]->girisYili);
                fprintf(calisanText,"%.2f\n",birimler[j]->birimCalisanlar[k]->maas);
            }
        }  
    }
    fclose(calisanText);
}
birim** birimDosyadanYazdir(FILE *birimText,char *birimDosya){
    birimText=fopen(birimDosya,"r");
    if(!birimText){
        printf("Dosya acilamadi!\n");
    }
    printf("Dosya basariyla acildi!\n");

    birim **birimler= (birim**)malloc(1*sizeof(birim*));
    int birimSayisi=0;
    // Dosyadaki her satırı okuyoruz
    while(!feof(birimText)){
        birim *olusanBirim=(birim*)malloc(sizeof(birim));
        if(!olusanBirim){
            printf("Bellek hatasi!\n");
            fclose(birimText);
            return NULL;
        }
         
        char birimAdiB[256];
        if(fscanf(birimText,"%s",birimAdiB)!=1){
            free(olusanBirim);
            break;
        }
        olusanBirim->birimAdi=(char*)malloc((strlen(birimAdiB)+1) * sizeof(char));
        if(!olusanBirim->birimAdi){
        printf("Bellek ayirma hatasi.\n");
        free(olusanBirim);
        fclose(birimText);
        return NULL;
        }
        strcpy(olusanBirim->birimAdi,birimAdiB);
         
        
        if(fscanf(birimText, "%hu %d", &olusanBirim->birimKodu, &olusanBirim->calisanSayisi) != 2){
             
            free(olusanBirim->birimAdi);
            free(olusanBirim);
            break;
        }
        olusanBirim->calisanSayisi=0;

        olusanBirim->birimCalisanlar=NULL;

         

        printf(olusanBirim->birimAdi);

        birim **temp=realloc(birimler,(birimSayisi+1) * sizeof(birim*));
        if(!temp){
            printf("Bellegi yeniden boyutlandirma hatasi!\n");
            free(olusanBirim->birimAdi);
            free(olusanBirim);
            fclose(birimText);
            return NULL;
        }
        birimler=temp;
        birimler[birimSayisi]=olusanBirim;
         
        birimSayisi++;
    }
    fclose(birimText);
    printf("Dosyadan bilgileri okuma tamamlandi.\n");
    return birimler;
}

void calisanDosyadanYazdir(birim **birimler,FILE *calisanText,char *calisanDosya){
    calisanText=fopen(calisanDosya,"r");
    if(!calisanText){
        printf("Dosya açilamadi!\n");
        return;
    }
    printf("calisan dosyasi basariyla acildi!\n");
    
    //verileri geçiçi olarak tutacak olan değişkenler
    char adB[100] , soyadB[100];
    unsigned short int birimKodu;
    float maas;
    int girisYili;
     //Dosyadaki her satırı okuyor
    while(fscanf(calisanText,"%s %s %hu %d %f",adB,soyadB,&birimKodu,&girisYili,&maas)==5){
         
        calisan *yeniCalisan=(calisan*)malloc(sizeof(calisan));
        if(!yeniCalisan){
        printf("Bellek ayirma hatasi!\n");
        fclose(calisanText);
        return;
        }

        yeniCalisan->calisanAdi=(char*)malloc((strlen(adB)+1) * sizeof(char));
        yeniCalisan->calisanSoyadi=(char*)malloc((strlen(soyadB)+1) * sizeof(char));
        //Bellek hatası kontrolü
        if(!yeniCalisan->calisanAdi || !yeniCalisan->calisanSoyadi){
            printf("Bellek hatasi.\n");
            free(yeniCalisan->calisanAdi);
            free(yeniCalisan->calisanSoyadi);
            free(yeniCalisan);
            fclose(calisanText);
            return;
        }
        strcpy(yeniCalisan->calisanAdi,adB);
        strcpy(yeniCalisan->calisanSoyadi,soyadB);
        yeniCalisan->birimKodu=birimKodu;
        yeniCalisan->maas=maas;
        yeniCalisan->girisYili=girisYili;

        for(int i=0;birimler[i] !=NULL;i++){
            if(birimler[i]->birimKodu==birimKodu){
                int yeniSayi=birimler[i]->calisanSayisi+1;
                calisan **temp=(calisan**)realloc(birimler[i]->birimCalisanlar,yeniSayi * sizeof(calisan*));
                if(!temp){
                    printf("Bellek hatasi!\n");
                    free(yeniCalisan->calisanAdi);
                    free(yeniCalisan->calisanSoyadi);
                    free(yeniCalisan);
                    fclose(calisanText);
                    return;
                }
                birimler[i]->birimCalisanlar=temp;
                birimler[i]->birimCalisanlar[birimler[i]->calisanSayisi]=yeniCalisan;
                birimler[i]->calisanSayisi++;
                break;
            }
        }
    }
    fclose(calisanText);
    printf("Calisanin bilgileri aktarildi!\n");
}
    
     

