/**
* @file proje1.h
* @description struct yapılarım ve fonksiyonların imzalarını burada tutuyorum
* @assignment 1.ödev
* @date 23.12.2024
* @author Melike yıldız- melike.yildiz@stu.fsm.edu.tr
*/

#include <stdio.h>

typedef struct
{
    char *calisanAdi;
    char *calisanSoyadi;
    unsigned short int birimKodu;
    float maas;
    int girisYili;
} calisan;

typedef struct
{
    char *birimAdi;
    unsigned short int birimKodu;
    calisan **birimCalisanlar;
    int calisanSayisi;
} birim;

calisan *returnCalisan(char *calisanAdi, char *calisanSoyadi, unsigned short int birimKodu, float maas, int girisYili);
birim *returnBirim(char *birimAdi, unsigned short int birimKodu);
calisan **birimDiziyeEkle(birim *hedefBirim, calisan *hedefCalisan);
birim **birimlerAta(birim *nesne,birim **birimler);
void calisanYazdir(calisan *c);
void birimYazdir(birim *b);
void birimDiziYazdir( birim **birimler);
float birimCalisanMaasHesapla(birim *b);
void ortalamaUstuMaas(birim *b);
void birimEnYuksekMaas(birim *b);
void maasDegistir(float istenenMaas, birim *b);
void dosyayaBirimYaz(birim **b, FILE *birimText, char *birimDosya);
void dosyayaCalisanYaz(FILE *calisanText, char *calisanDosya, birim **birimler);
birim** birimDosyadanYazdir(FILE *birimText, char *birimDosya);
void calisanDosyadanYazdir(birim **birimler, FILE *calisanText, char *calisanDosya);